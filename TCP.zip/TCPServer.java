package cs250.hw3;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;
import java.net.InetAddress;

public class TCPServer {

    public static void main(String[] args) throws IOException{

        int port = Integer.parseInt(args[0]);
        int seed = Integer.parseInt(args[1]);
        int numMessages = Integer.parseInt(args[2]);

        if(port <= 1024 || port > 65535){
            System.err.println("Port must be > 1024 and <= 65535");
            return;
        }

        ServerSocket serverSocket = null;
        Socket clientSocket = null;
        Socket clientSocket2 = null;

        try{
            serverSocket = new ServerSocket(port);
            
            InetAddress localhost = InetAddress.getLocalHost();
            String hostname = localhost.getHostName();
            String ipAddress = localhost.getHostAddress();
            System.out.println("IP Address: " + hostname + "/" + ipAddress);
            System.out.println("Port Number " + port);
            System.out.println("waiting for client...");

            clientSocket = serverSocket.accept();
            clientSocket2 = serverSocket.accept();
            
            System.out.println("Clients Connected!");
            System.out.println("Sending config to clients...");

            DataInputStream din = new DataInputStream(clientSocket.getInputStream());
            DataOutputStream dout = new DataOutputStream(clientSocket.getOutputStream());
            
            DataInputStream din2 = new DataInputStream(clientSocket2.getInputStream());
            DataOutputStream dout2 = new DataOutputStream(clientSocket2.getOutputStream());
            
            Random rand = new Random(seed);
            
            int clientSeed = rand.nextInt();
            dout.writeInt(numMessages);
            dout.writeInt(clientSeed);
            dout.flush();
            System.out.println(clientSocket.getInetAddress().getHostName() + " " + clientSeed);

            int clientSeed2 = rand.nextInt();
            dout2.writeInt(numMessages);
            dout2.writeInt(clientSeed2);
            dout2.flush();
            System.out.println(clientSocket2.getInetAddress().getHostName() + " " + clientSeed2);

            System.out.println("Finished sending config to clients.");
            System.out.println("Starting to listen for client messages...");

            long receiverSum1 = 0;
            int numOfReceivedMessages1 = 0;
            long receiverSum2 = 0;
            int numOfReceivedMessages2 = 0;
            
            for(int i=0; i<numMessages; i++){
                int message = din.readInt();
                receiverSum1 += message;
                numOfReceivedMessages1++;
                
                dout2.writeInt(message);
                dout2.flush();
            }

            for(int i=0; i<numMessages; i++){
                int message = din2.readInt();
                receiverSum2 += message;
                numOfReceivedMessages2++;
                
                dout.writeInt(message);
                dout.flush();
            }
            
            System.out.println("Finished listening for client messages.");
            System.out.println(clientSocket.getInetAddress().getHostName());
            System.out.println("    Messages received: " + numOfReceivedMessages1);
            System.out.println("    Sum received: " + receiverSum1);
            System.out.println(clientSocket2.getInetAddress().getHostName());
            System.out.println("    Messages received: " + numOfReceivedMessages2);
            System.out.println("    Sum received: " + receiverSum2);

            din.close();
            dout.close();
            din2.close();
            dout2.close();
            
        }catch(IOException exception){
            System.err.println("Exception: " + exception.getMessage());
        }finally{
            try{
                if(serverSocket != null) serverSocket.close();
                if(clientSocket != null) clientSocket.close();
                if(clientSocket2 != null) clientSocket2.close();
            }catch(IOException e){
                System.out.println("Error" + e.getMessage());
            }
        }
    }
}
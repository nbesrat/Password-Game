package cs250.hw3;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Random;

public class TCPClient {
    public static void main(String[] args){
        String serverHost = args[0];
        int serverPort = Integer.parseInt(args[1]);
        
        try {
            Socket socket = new Socket();
            socket.connect(new InetSocketAddress(serverHost, serverPort), 1000);
            
            DataInputStream din = new DataInputStream(socket.getInputStream());
            DataOutputStream dout = new DataOutputStream(socket.getOutputStream());
            
            int numMessages = din.readInt();
            int clientSeed = din.readInt();
            
            System.out.println("Received config");
            System.out.println("number of messages = " + numMessages);
            System.out.println("seed = " + clientSeed);
            System.out.println("Starting to send messages to server...");
            
            Random rand = new Random(clientSeed);
            
            long senderSum = 0;
            int numOfSentMessages = 0;
            
            for(int i=0; i<numMessages; i++){
                int message = rand.nextInt();
                dout.writeInt(message);
                dout.flush();
                
                senderSum += message;
                numOfSentMessages++;
            }
            
            System.out.println("Finished sending messages to server.");
            System.out.println("Total messages sent: " + numOfSentMessages);
            System.out.println("Sum of messages sent: " + senderSum);
            System.out.println("Starting to listen for messages from server...");
            
            long receiverSum = 0;
            int numOfReceivedMessages = 0;
            
            for(int i=0; i<numMessages; i++){
                int message = din.readInt();
                receiverSum += message;
                numOfReceivedMessages++;
            }
            
            System.out.println("Finished listening for messages from server.");
            System.out.println("Total messages received: " + numOfReceivedMessages);
            System.out.println("Sum of messages received: " + receiverSum);
            
            din.close();
            dout.close();
            socket.close();
        } catch (IOException exception) {
            System.out.println("Exception: " + exception.getMessage());
        }
    }
}

class TCPClient2 {
    public static void main(String[] args){
        String serverHost = args[0];
        int serverPort = Integer.parseInt(args[1]);
        
        try{
            Socket socket = new Socket();
            socket.connect(new InetSocketAddress(serverHost, serverPort), 1000);
            
            DataInputStream din = new DataInputStream(socket.getInputStream());
            DataOutputStream dout = new DataOutputStream(socket.getOutputStream());
            
            int numMessages = din.readInt();
            int clientSeed = din.readInt();
            
            System.out.println("Received config");
            System.out.println("number of messages = " + numMessages);
            System.out.println("seed = " + clientSeed);
            System.out.println("Starting to send messages to server...");
            
            Random rand = new Random(clientSeed);
            
            long senderSum = 0;
            int numOfSentMessages = 0;
            
            for(int i = 0; i < numMessages; i++) {
                int message = rand.nextInt();
                dout.writeInt(message);
                dout.flush();
                
                senderSum += message;
        numOfSentMessages++;
            }
            
            System.out.println("Finished sending messages to server.");
            System.out.println("Total messages sent: " + numOfSentMessages);
            System.out.println("Sum of messages sent: " + senderSum);
            System.out.println("Starting to listen for messages from server...");
            
            long receiverSum = 0;
            int numOfReceivedMessages = 0;
            
            for(int i = 0; i < numMessages; i++){
                int message = din.readInt();
                receiverSum += message;
                numOfReceivedMessages++;
            }
            
            System.out.println("Finished listening for messages from server.");
            System.out.println("Total messages received: " + numOfReceivedMessages);
            System.out.println("Sum of messages received: " + receiverSum);
            
            din.close();
            dout.close();
            socket.close();
        }catch(IOException exception){
            System.out.println("Exception: " + exception.getMessage());
        }
    }
}